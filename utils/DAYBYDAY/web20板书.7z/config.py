secret_key = 'web18 bbs'
user_file_dir = r'C:\Users\gua\Desktop\web5\web20板书(1)\user_image'
accept_user_file_type = ['jpg', 'gif', 'png']
